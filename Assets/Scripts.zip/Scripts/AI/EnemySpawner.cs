using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    [Header("Enemy Prefabs")]
    public List<GameObject> enemyPrefabs = new List<GameObject>();

    [Header("Spawn Points")]
    public List<Transform> spawnPoints = new List<Transform>();

    [Header("References")]
    public Transform player;

    [Header("Optional World UI")]
    public GameObject worldHealthBarPrefab;

    [Header("Spawn Settings")]
    public bool spawnOnStart = true;
    public float spawnDelay = 0.5f;

    public bool spawnRepeatedly = false;
    public float spawnInterval = 6f;

    public int maxAliveEnemies = 5;

    private readonly List<GameObject> aliveEnemies = new List<GameObject>();

    private void Start()
    {
        if (!spawnOnStart) return;

        if (spawnDelay <= 0f) SpawnOne();
        else Invoke(nameof(SpawnOne), spawnDelay);

        if (spawnRepeatedly)
            InvokeRepeating(nameof(SpawnOne), Mathf.Max(spawnDelay, 0.01f), Mathf.Max(spawnInterval, 0.25f));
    }

    public void SpawnOne()
    {
        CleanupDead();

        if (enemyPrefabs == null || enemyPrefabs.Count == 0)
        {
            Debug.LogWarning("[EnemySpawner] No enemy prefabs assigned.");
            return;
        }

        if (spawnPoints == null || spawnPoints.Count == 0)
        {
            Debug.LogWarning("[EnemySpawner] No spawn points assigned.");
            return;
        }

        if (maxAliveEnemies > 0 && aliveEnemies.Count >= maxAliveEnemies)
            return;

        var prefab = enemyPrefabs[Random.Range(0, enemyPrefabs.Count)];
        var sp = spawnPoints[Random.Range(0, spawnPoints.Count)];

        if (prefab == null || sp == null)
        {
            Debug.LogWarning("[EnemySpawner] Missing prefab or spawn point.");
            return;
        }

        var enemy = Instantiate(prefab, sp.position, sp.rotation);
        aliveEnemies.Add(enemy);

        // IMPORTANT: don't assume EnemyAI has "player"
        TryAssignTarget(enemy, player);

        // Optional: auto-spawn a WorldHealthBar prefab if provided
        if (worldHealthBarPrefab != null)
        {
            var hbSpawner = enemy.GetComponent<HealthBarSpawner>();
            if (hbSpawner == null) hbSpawner = enemy.AddComponent<HealthBarSpawner>();

            hbSpawner.worldHealthBarPrefab = worldHealthBarPrefab;
            hbSpawner.target = enemy.transform;
            hbSpawner.health = enemy.GetComponent<Health>();
            hbSpawner.faceCamera = Camera.main;

            hbSpawner.SpawnNow();
        }
    }

    private void TryAssignTarget(GameObject enemy, Transform playerTarget)
    {
        if (enemy == null || playerTarget == null) return;

        // Try common patterns without compile-time dependency:
        // 1) a method SetTarget(Transform)
        // 2) a method SetPlayer(Transform)
        // 3) fields: target / player / playerTransform / playerTarget

        foreach (var mb in enemy.GetComponentsInChildren<MonoBehaviour>(true))
        {
            if (mb == null) continue;

            var t = mb.GetType();

            // method: SetTarget(Transform)
            var setTarget = t.GetMethod("SetTarget", new[] { typeof(Transform) });
            if (setTarget != null)
            {
                setTarget.Invoke(mb, new object[] { playerTarget });
                continue;
            }

            // method: SetPlayer(Transform)
            var setPlayer = t.GetMethod("SetPlayer", new[] { typeof(Transform) });
            if (setPlayer != null)
            {
                setPlayer.Invoke(mb, new object[] { playerTarget });
                continue;
            }

            // field: target / player / playerTransform / playerTarget
            var field =
                t.GetField("target") ??
                t.GetField("player") ??
                t.GetField("playerTransform") ??
                t.GetField("playerTarget");

            if (field != null && field.FieldType == typeof(Transform))
            {
                field.SetValue(mb, playerTarget);
                continue;
            }

            // property: Target / target / Player / player
            var prop =
                t.GetProperty("Target") ??
                t.GetProperty("target") ??
                t.GetProperty("Player") ??
                t.GetProperty("player");

            if (prop != null && prop.PropertyType == typeof(Transform) && prop.CanWrite)
            {
                prop.SetValue(mb, playerTarget);
                continue;
            }
        }
    }

    private void CleanupDead()
    {
        for (int i = aliveEnemies.Count - 1; i >= 0; i--)
        {
            if (aliveEnemies[i] == null)
                aliveEnemies.RemoveAt(i);
        }
    }
}
