using UnityEngine;
using UnityEngine.AI;

public class EnemyAI : MonoBehaviour
{
    public Transform target;                 // player
    public float chaseDistance = 12f;

    [Header("Attack Choice")]
    public bool hasGun = false;
    public float meleeDistance = 1.8f;
    public float gunDistance = 10f;

    [Header("Refs")]
    public NavMeshAgent agent;
    public Animator animator;
    public string speedParam = "Speed";

    public MeleeAttack melee;
    public GunAttack gun;

    private bool attacking;

    void Awake()
    {
        if (agent == null) agent = GetComponent<NavMeshAgent>();
        if (animator == null) animator = GetComponentInChildren<Animator>();
        if (animator != null) animator.applyRootMotion = false;
    }

    void Update()
    {
        if (target == null) return;

        float dist = Vector3.Distance(transform.position, target.position);

        if (dist > chaseDistance)
        {
            StopMoving();
            UpdateAnim();
            return;
        }

        FaceTarget();

        if (attacking)
        {
            UpdateAnim();
            return;
        }

        if (!hasGun)
        {
            if (dist > meleeDistance) Chase();
            else StartMelee();
        }
        else
        {
            if (dist <= meleeDistance && melee != null) StartMelee();
            else if (dist <= gunDistance && gun != null) StartGun();
            else Chase();
        }

        UpdateAnim();
    }

    void FaceTarget()
    {
        Vector3 dir = target.position - transform.position;
        dir.y = 0;
        if (dir.sqrMagnitude < 0.001f) return;
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 10f * Time.deltaTime);
    }

    void Chase()
    {
        agent.isStopped = false;
        agent.SetDestination(target.position);
    }

    void StopMoving()
    {
        agent.isStopped = true;
        agent.ResetPath();
    }

    void StartMelee()
    {
        attacking = true;
        StopMoving();

        if (animator != null) animator.SetTrigger("Attack");

        Invoke(nameof(EndAttack), 0.8f);
    }

    void StartGun()
    {
        attacking = true;
        StopMoving();

        if (animator != null) animator.SetTrigger("Shoot");
        gun.FireAt(target);

        Invoke(nameof(EndAttack), 0.5f);
    }

    void EndAttack()
    {
        attacking = false;
    }

    void UpdateAnim()
    {
        if (animator == null || agent == null) return;
        float normalized = (agent.speed > 0.01f) ? Mathf.Clamp01(agent.velocity.magnitude / agent.speed) : 0f;
        animator.SetFloat(speedParam, normalized, 0.1f, Time.deltaTime);
    }
}
