using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

public class WorldHealthBar : MonoBehaviour
{
    [Header("UI")]
    public Slider slider;

    [Header("Follow")]
    public Transform target;
    public Vector3 worldOffset = new Vector3(0f, 2.0f, 0f);

    [Header("Camera")]
    public Camera faceCamera;

    [Header("Health Source (optional)")]
    public MonoBehaviour healthSource; // drag your Health component here if you want

    // Cached reflection lookups (so it is fast)
    private Func<float> _getCurrent;
    private Func<float> _getMax;

    private void Awake()
    {
        if (slider == null)
            slider = GetComponentInChildren<Slider>(true);

        if (faceCamera == null)
            faceCamera = Camera.main;
    }

    /// <summary>
    /// Initialize with any health component (your Health script), a target to follow, and optional camera.
    /// </summary>
    public void Init(MonoBehaviour health, Transform followTarget, Camera cam = null)
    {
        healthSource = health;
        target = followTarget;
        if (cam != null) faceCamera = cam;

        BuildHealthAccessors(healthSource);

        // set initial values once
        UpdateSlider();
    }

    private void LateUpdate()
    {
        if (target == null)
        {
            Destroy(gameObject);
            return;
        }

        // Follow target
        transform.position = target.position + worldOffset;

        // Face camera
        if (faceCamera != null)
            transform.forward = faceCamera.transform.forward;

        UpdateSlider();
    }

    private void UpdateSlider()
    {
        if (slider == null || healthSource == null) return;

        // if accessors not built (e.g. health assigned later), build them
        if (_getCurrent == null || _getMax == null)
            BuildHealthAccessors(healthSource);

        float max = SafeCall(_getMax, 100f);
        float cur = SafeCall(_getCurrent, max);

        // clamp safety
        if (max <= 0.001f) max = 1f;
        cur = Mathf.Clamp(cur, 0f, max);

        slider.minValue = 0f;
        slider.maxValue = max;
        slider.value = cur;
    }

    private float SafeCall(Func<float> fn, float fallback)
    {
        try
        {
            return fn != null ? fn() : fallback;
        }
        catch
        {
            return fallback;
        }
    }

    private void BuildHealthAccessors(MonoBehaviour health)
    {
        if (health == null)
        {
            _getCurrent = null;
            _getMax = null;
            return;
        }

        var type = health.GetType();

        // Try to find MAX health (properties/fields/methods in common names)
        _getMax = TryMakeGetter(health, type,
            // properties
            new[] { "MaxHealth", "maxHealth", "MaximumHealth", "maxHP", "MaxHP", "max" },
            // fields
            new[] { "MaxHealth", "maxHealth", "maximumHealth", "maxHP", "MaxHP", "max" },
            // methods
            new[] { "GetMaxHealth", "GetMaximumHealth", "GetMaxHP" }
        );

        // Try to find CURRENT health
        _getCurrent = TryMakeGetter(health, type,
            new[] { "CurrentHealth", "currentHealth", "Health", "health", "HP", "hp", "currentHP", "CurrentHP" },
            new[] { "CurrentHealth", "currentHealth", "health", "HP", "hp", "currentHP", "CurrentHP" },
            new[] { "GetCurrentHealth", "GetHealth", "GetHP", "GetCurrentHP" }
        );

        // If we failed, use safe fallbacks so game still runs
        if (_getMax == null) _getMax = () => 100f;
        if (_getCurrent == null) _getCurrent = () => _getMax();
    }

    private Func<float> TryMakeGetter(object instance, Type type, string[] propNames, string[] fieldNames, string[] methodNames)
    {
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;

        // 1) properties
        foreach (var name in propNames)
        {
            var p = type.GetProperty(name, flags);
            if (p != null && p.CanRead)
            {
                return () => ConvertToFloat(p.GetValue(instance, null));
            }
        }

        // 2) fields
        foreach (var name in fieldNames)
        {
            var f = type.GetField(name, flags);
            if (f != null)
            {
                return () => ConvertToFloat(f.GetValue(instance));
            }
        }

        // 3) methods
        foreach (var name in methodNames)
        {
            var m = type.GetMethod(name, flags, null, Type.EmptyTypes, null);
            if (m != null)
            {
                return () => ConvertToFloat(m.Invoke(instance, null));
            }
        }

        return null;
    }

    private float ConvertToFloat(object value)
    {
        if (value == null) return 0f;

        if (value is float f) return f;
        if (value is int i) return i;
        if (value is double d) return (float)d;
        if (value is long l) return l;

        // try parse string etc.
        if (float.TryParse(value.ToString(), out var parsed))
            return parsed;

        return 0f;
    }
}
