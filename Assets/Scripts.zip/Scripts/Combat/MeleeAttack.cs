using UnityEngine;

public class MeleeAttack : MonoBehaviour
{
    public Transform hitPoint;           // empty object in front of attacker
    public LayerMask targetLayers;       // Player layer / Enemy layer
    public SkillData skill;
    public int skillLevel = 1;

    public GameObject owner;

    public void DoHit()
    {
        if (skill == null || hitPoint == null) return;

        float dmg = skill.GetDamage(skillLevel);

        Collider[] hits = Physics.OverlapSphere(hitPoint.position, skill.hitRadius, targetLayers);

        foreach (var c in hits)
        {
            if (owner != null && c.gameObject == owner) continue;

            IDamageable d = c.GetComponentInParent<IDamageable>();
            if (d != null)
            {
                Vector3 dir = (c.transform.position - owner.transform.position).normalized;
                d.TakeDamage(new DamageInfo(dmg, hitPoint.position, dir, owner, skill.skillName));
            }
        }
    }

    void OnDrawGizmosSelected()
    {
        if (hitPoint == null || skill == null) return;
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(hitPoint.position, skill.hitRadius);
    }
}
