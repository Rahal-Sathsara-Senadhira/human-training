public interface IDamageable
{
    void TakeDamage(DamageInfo dmg);
}
